name="Chessmasters Wounding System";
picture="cws_logo_ca.paa";
action="https://github.com/chessmaster42/cws_injury";
actionName="Website";
description = "Wounding system for Arma 3";